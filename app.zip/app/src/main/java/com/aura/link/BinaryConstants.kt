package com.aura.link

const val BINARY_MESSAGE_SIZE = 20