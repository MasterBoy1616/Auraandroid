package com.aura.link

enum class OutputMode {
    HEADSET,
    SPEAKER
}