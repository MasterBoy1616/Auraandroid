package com.aura.link

enum class Gender {
    MALE,
    FEMALE,
    UNKNOWN
}